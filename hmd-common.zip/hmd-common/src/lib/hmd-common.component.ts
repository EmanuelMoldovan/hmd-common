import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hmd-hmd-common',
  template: `
    <p>
      hmd-common works!
    </p>
  `,
  styles: [
  ]
})
export class HmdCommonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
