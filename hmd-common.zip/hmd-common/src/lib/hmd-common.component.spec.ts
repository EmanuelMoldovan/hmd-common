import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HmdCommonComponent } from './hmd-common.component';

describe('HmdCommonComponent', () => {
  let component: HmdCommonComponent;
  let fixture: ComponentFixture<HmdCommonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HmdCommonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HmdCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
