import { APP_INITIALIZER, ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderService } from './loader.service';
import { LOADING_SERVICE } from './loader-service-token';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderHttpInterceptorService } from './loader-http-interceptor.service';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
  ]
})
export class LoaderServiceModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: LoaderServiceModule,
      providers: [
        LoaderService,
        {
          provide: LOADING_SERVICE,
          useExisting: LoaderService
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: LoaderHttpInterceptorService,
          multi: true
        }
      ]
    }
  }
}
