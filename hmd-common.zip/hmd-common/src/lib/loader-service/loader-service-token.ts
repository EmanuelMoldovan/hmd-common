import { InjectionToken } from "@angular/core";
import { LoaderService } from "./loader.service";

export const LOADING_SERVICE = new InjectionToken<LoaderService>('LoaderService');