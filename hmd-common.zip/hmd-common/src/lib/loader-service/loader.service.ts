import { Injectable, InjectionToken } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class LoaderService {

  public isLoading: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  // public isLoading = this.isLoading$.asObservable();
  // public get isLoading(): Observable<boolean> {
  //   return this.isLoading$.asObservable();
  // }
  // public set isLoading(value: boolean) {
  //   this.isLoading$.next(value);
  // }
  constructor() { }
}
