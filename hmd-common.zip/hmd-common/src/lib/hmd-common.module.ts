import { NgModule } from '@angular/core';
import { HmdCommonComponent } from './hmd-common.component';



@NgModule({
  declarations: [HmdCommonComponent],
  imports: [
  ],
  exports: [HmdCommonComponent]
})
export class HmdCommonModule { }
