import { TestBed } from '@angular/core/testing';

import { HmdCommonService } from './hmd-common.service';

describe('HmdCommonService', () => {
  let service: HmdCommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HmdCommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
